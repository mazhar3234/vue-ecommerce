<template>
	 <div class="widget widget-brand mb-4 border rounded p-4">
            <h5 class="widget-title mb-3">Price</h5>
           <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="priceCheck1">
              <label class="custom-control-label" for="priceCheck1">Under $10</label>
            </div>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="priceCheck1">
              <label class="custom-control-label" for="priceCheck1">$10 - $100</label>
            </div>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="priceCheck2">
              <label class="custom-control-label" for="priceCheck2">$100 - $200</label>
            </div>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="priceCheck3">
              <label class="custom-control-label" for="priceCheck3">$200 - $300</label>
            </div>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="priceCheck4">
              <label class="custom-control-label" for="priceCheck4">$300 - $400</label>
            </div>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="priceCheck5">
              <label class="custom-control-label" for="priceCheck5">$400 - $1000</label>
            </div>
          </div>
</template>

<script>
	
</script>

<style>
	
</style>