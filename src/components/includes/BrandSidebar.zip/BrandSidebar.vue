<template>
	 <div class="widget widget-brand mb-4 border rounded p-4">
            <h5 class="widget-title mb-3">Brand</h5>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="brandCheck1">
              <label class="custom-control-label" for="brandCheck1">Covmed</label>
            </div>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="brandCheck2">
              <label class="custom-control-label" for="brandCheck2">Tiagoo</label>
            </div>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="brandCheck3">
              <label class="custom-control-label" for="brandCheck3">Organtic</label>
            </div>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="brandCheck4">
              <label class="custom-control-label" for="brandCheck4">Dealsdot</label>
            </div>
            <div class="custom-control custom-checkbox mb-2">
              <input type="checkbox" class="custom-control-input" id="brandCheck5">
              <label class="custom-control-label" for="brandCheck5">Harrier</label>
            </div>
            <div class="custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input" id="brandCheck6">
              <label class="custom-control-label" for="brandCheck6">Unicorn</label>
            </div>
          </div>


</template>


<script>
	
	
</script>


<style></style>