<template>
	<div class="widget widget-size mb-4 border rounded p-4">
            <h5 class="widget-title mb-3">Size</h5>
            <ul class="list-inline clearfix">
              <li>
                <input name="sc" id="xs-size" type="radio">
                <label for="xs-size">XS</label>
              </li>
              <li>
                <input name="sc" id="s-size" type="radio">
                <label for="s-size">S</label>
              </li>
              <li>
                <input name="sc" id="m-size" checked="" type="radio">
                <label for="m-size">M</label>
              </li>
              <li>
                <input name="sc" id="l-size" type="radio">
                <label for="l-size">L</label>
              </li>
              <li>
                <input name="sc" id="xl-size" type="radio">
                <label for="xl-size">XL</label>
              </li>



            </ul>
          </div>

</template>


<script>
	
</script>


<style>
	
</style>