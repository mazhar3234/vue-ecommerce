<template>
	<div class="widget mb-4">
          <div class="position-relative rounded overflow-hidden">
            <!-- Background -->
            <img class="img-fluid hover-zoom" src="../../../static/assets/images/product-ad/side-banner.jpg" alt="">
            <!-- Body -->
            <div class="position-absolute top-50 pl-5 side-banner">
              <h6 class="text-dark">Todays Deals</h6>
              <!-- Heading -->
              <h4 class="font-w-6 text-dark">Accessories <br>
                Special</h4>
              <!-- Link --> <a class="more-link" href="#">Shop Now </a> </div>
          </div>
          </div>
</template>

<script>

</script>

<style>
	
</style>