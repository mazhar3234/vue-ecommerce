<template>
<div class="widget widget-categories mb-4 border rounded p-4">
            <h5 class="widget-title mb-3">Categories</h5>
            <div id="accordion" class="accordion">
              <div class="card border-0 mb-2">
                <div class="card-header">
                  <h6 class="mb-0">
              <a class="link-title" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="true">Clothing</a>
              </h6>
                </div>
                <div id="collapse1" class="collapse show" data-parent="#accordion">
                  <div class="card-body text-muted">
                    <ul class="list-unstyled">
                                  <li> <a href="#">Western Wear</a></li>
                                  <li> <a href="#">Fitness &amp; Outdoors</a></li>
                                  <li> <a href="#">Ethnic Wear</a></li>
                                  <li> <a href="#">Beach Clothing</a></li>
                                  <li> <a href="#">Swimsuits</a></li>
                                  <li> <a href="#">Casual Dresses</a></li>
                                  <li> <a href="#">Raincoats</a></li>
                                  <li> <a href="#">Sleep &amp; Lounge Wear</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="card border-0 mb-2">
                <div class="card-header">
                  <h6 class="mb-0">
              <a class="link-title" data-toggle="collapse" data-parent="#accordion" href="#collapse2">Accessories</a>
              </h6>
                </div>
                <div id="collapse2" class="collapse" data-parent="#accordion">
                  <div class="card-body text-muted">
                    <ul class="list-unstyled">
                      <li><a href="#">Handkerchiefs</a>
                      </li>
                      <li><a href="#">Suspenders</a>
                      </li>
                      <li><a href="#">Pocket Squares</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="card border-0 mb-2">
                <div class="card-header">
                  <h6 class="mb-0">
              <a class="link-title" data-toggle="collapse" data-parent="#accordion" href="#collapse3">Jewellery</a>
              </h6>
                </div>
                <div id="collapse3" class="collapse" data-parent="#accordion">
                  <div class="card-body text-muted">
                    <ul class="list-unstyled">
                      <li><a href="#">Chains & Necklaces</a>
                      </li>
                      <li><a href="#">Earrings</a>
                      </li>
                      <li><a href="#">Pendants</a>
                      </li>
                      <li><a href="#">Bangles & Bracelets</a>
                      </li>
                      <li><a href="#">Anklets</a>
                      </li>
                      <li><a href="#">Nose Rings & Pins</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="card border-0 mb-2">
                <div class="card-header">
                  <h6 class="mb-0">
              <a class="link-title" data-toggle="collapse" data-parent="#accordion" href="#collapse4">Footwear</a>
              </h6>
                </div>
                <div id="collapse4" class="collapse" data-parent="#accordion">
                  <div class="card-body text-muted">
                    <ul class="list-unstyled">
                      <li><a href="#">Running Shoes</a>
                      </li>
                      <li><a href="#">Sneakers</a>
                      </li>
                      <li><a href="#">Casual Shoes</a>
                      </li>
                      <li><a href="#">Formal Shoes</a>
                      </li>
                      <li><a href="#">Hiking Footwear</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="card border-0 mb-2">
                <div class="card-header">
                  <h6 class="mb-0">
              <a class="link-title" data-toggle="collapse" data-parent="#accordion" href="#collapse5">Electronics</a>
              </h6>
                </div>
                <div id="collapse5" class="collapse" data-parent="#accordion">
                  <div class="card-body text-muted">
                    <ul class="list-unstyled">
                      <li><a href="#">Cameras</a>
                      </li>
                      <li><a href="#">Television</a>
                      </li>
                      <li><a href="#">Computers</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="card border-0">
                <div class="card-header">
                  <h6 class="mb-0">
              <a class="link-title" data-toggle="collapse" data-parent="#accordion" href="#collapse6">Watches</a>
              </h6>
                </div>
                <div id="collapse6" class="collapse" data-parent="#accordion">
                  <div class="card-body text-muted">
                    <ul class="list-unstyled">
                      <li><a href="#">Waterproof</a>
                      </li>
                      <li><a href="#">Sports</a>
                      </li>
                      <li><a href="#">Stylish</a>
                      </li>
                      <li><a href="#">Metal</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
